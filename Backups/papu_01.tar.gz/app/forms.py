from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, DateField, IntegerField
from wtforms.validators import DataRequired

class LoginForm(FlaskForm):
    usuario = StringField('Usuario', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Recordarme')
    submit = SubmitField('Ingresar')


class RegistroForm(FlaskForm):
    apellido = StringField('Apellido', validators=[DataRequired()])
    nombre = StringField('Nombre', validators=[DataRequired()])
    dni = StringField('DNI', validators=[DataRequired()])
    fnacto = DateField('Fecha de Nacimiento')
    usuario = StringField('Usuario', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember_me = BooleanField('Recordarme')
    submit = SubmitField('Ingresar')
    
class AnioForm(FlaskForm):
	numero = StringField('Numero', validators=[DataRequired()])

class CargoDocenteForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])

class CicloLectivoForm(FlaskForm):
	anio = IntegerField('Anio', validators=[DataRequired()])
	finicio = DateField('Finicio', validators=[DataRequired()])
	ffin = DateField('Ffin', validators=[DataRequired()])

class InstitucionForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])
	domicilio = StringField('Domicilio', validators=[DataRequired()])

class MateriaForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])

class PersonaForm(FlaskForm):
	apellido = StringField('Apellido', validators=[DataRequired()])
	nombre = StringField('Nombre', validators=[DataRequired()])
	dni = IntegerField('Dni', validators=[DataRequired()])
	fnacto = DateField('Fnacto', validators=[DataRequired()])

class TipoContactoForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])

class TurnoForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])

class ContactoPersonaForm(FlaskForm):
	persona_id = IntegerField('Persona_Id', validators=[DataRequired()])
	tipocontacto_id = IntegerField('Tipocontacto_Id', validators=[DataRequired()])

class DocenteForm(FlaskForm):
	legajo = IntegerField('Legajo', validators=[DataRequired()])
	persona_id = IntegerField('Persona_Id', validators=[DataRequired()])

class UsuarioForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])
	password_hash = StringField('Password_Hash', validators=[DataRequired()])
	persona_id = IntegerField('Persona_Id', validators=[DataRequired()])

class DocenteCargoForm(FlaskForm):
	docente_id = IntegerField('Docente_Id', validators=[DataRequired()])
	cargodocente_id = IntegerField('Cargodocente_Id', validators=[DataRequired()])
	finicio = DateField('Finicio', validators=[DataRequired()])
	ffin = DateField('Ffin', validators=[DataRequired()])

class PosteoForm(FlaskForm):
	texto = StringField('Texto', validators=[DataRequired()])
	fecha = DateField('Fecha', validators=[DataRequired()])
	usuario_id = IntegerField('Usuario_Id', validators=[DataRequired()])

class AlumnoForm(FlaskForm):
	legajo = IntegerField('Legajo', validators=[DataRequired()])
	persona_id = IntegerField('Persona_Id', validators=[DataRequired()])
	fingreso = DateField('Fingreso', validators=[DataRequired()])
	fegreso = DateField('Fegreso', validators=[DataRequired()])

class AlumnoComisionForm(FlaskForm):
	comision_id = IntegerField('Comision_Id', validators=[DataRequired()])
	alumno_id = IntegerField('Alumno_Id', validators=[DataRequired()])

class CarreraForm(FlaskForm):
	institucion_id = IntegerField('Institucion_Id', validators=[DataRequired()])
	nombre = StringField('Nombre', validators=[DataRequired()])
	anios = IntegerField('Anios', validators=[DataRequired()])

class ComisionForm(FlaskForm):
	ciclolectivo_id = IntegerField('Ciclolectivo_Id', validators=[DataRequired()])
	cuatrimestre_id = IntegerField('Cuatrimestre_Id', validators=[DataRequired()])
	turno_id = IntegerField('Turno_Id', validators=[DataRequired()])
	materiadocente_id = IntegerField('Materiadocente_Id', validators=[DataRequired()])

class CuatrimestreForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])
	ciclolectivo_id = IntegerField('Ciclolectivo_Id', validators=[DataRequired()])

class MateriaDocenteForm(FlaskForm):
	docente_id = IntegerField('Docente_Id', validators=[DataRequired()])
	materiaplan_id = IntegerField('Materiaplan_Id', validators=[DataRequired()])

class MateriaPlanForm(FlaskForm):
	planestudio_id = IntegerField('Planestudio_Id', validators=[DataRequired()])
	materia_id = IntegerField('Materia_Id', validators=[DataRequired()])
	anio_id = IntegerField('Anio_Id', validators=[DataRequired()])

class PlanEstudioForm(FlaskForm):
	nombre = StringField('Nombre', validators=[DataRequired()])
	finicio = DateField('Finicio', validators=[DataRequired()])
	ffin = DateField('Ffin', validators=[DataRequired()])
	carrera_id = IntegerField('Carrera_Id', validators=[DataRequired()])
