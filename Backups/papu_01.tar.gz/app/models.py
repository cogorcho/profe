from datetime import datetime
from app import db, login
import typing
from flask_login import UserMixin
from dataclasses import dataclass
import inspect

class Institucion(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(256), index=True, unique=True, nullable=False)
    domicilio = db.Column(db.String(256),nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Carrera(db.Model):
    __table_args__ = (
        db.UniqueConstraint('institucion_id', 'nombre', name='uix_carrera_institucion'),
    )
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    institucion_id = db.Column(db.Integer(), db.ForeignKey(Institucion.id), nullable=False)
    nombre = db.Column(db.String(64), index=True, nullable=False)
    anios = db.Column(db.Integer(), nullable=False, default=0)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class CicloLectivo(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    anio = db.Column(db.Integer(), index=True, unique=True, nullable=False)
    finicio = db.Column(db.DateTime, default=datetime.now().date().replace(month=1, day=1), nullable=False)
    ffin = db.Column(db.DateTime, default=datetime.now().date().replace(month=12, day=31), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Cuatrimestre(db.Model):
    __table_args__ = (
        db.UniqueConstraint('ciclolectivo_id', 'nombre', name='uix_cuatrimestre_ciclo'),
    )
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(64), index=True, unique=True, nullable=False)
    ciclolectivo_id = db.Column(db.Integer(), db.ForeignKey(CicloLectivo.id), nullable=False)

    def __repr__(self) -> str:
        return f"{self.to_dict()}"
        #return 'OK OK'
    def to_dict(self):
        return {field.name:getattr(self, field.name) for field in self.__table__.c}

class Turno(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(64), index=True, unique=True, nullable=False)

    def __repr__(self) -> str:
        return f"{self.to_dict()}"
        #return 'OK OK'
    def to_dict(self):
        return {field.name:getattr(self, field.name) for field in self.__table__.c}

class Materia(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(64), index=True, unique=True, nullable=False)
    def __repr__(self) -> str:
        return str(self.to_dict())
        #return 'OK OK'
    def to_dict(self):
        return {field.name:getattr(self, field.name) for field in self.__table__.c}

class PlanEstudio(db.Model):
    __table_args__ = (
        db.UniqueConstraint('carrera_id', 'nombre', name='uix_plan_carrera'),
    )
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(64), index=True, unique=True, nullable=False)
    finicio = db.Column(db.DateTime)
    ffin = db.Column(db.DateTime)
    carrera_id = db.Column(db.Integer(), db.ForeignKey(Carrera.id), nullable=False)

    def __repr__(self) -> str:
        return str(self.to_dict())
        #return 'OK OK'
    def to_dict(self):
        return {field.name:getattr(self, field.name) for field in self.__table__.c}

# 1ro, 2o, 3er anio, etc
class Anio(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    numero = db.Column(db.String(64), index=True, unique=True, nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class MateriaPlan(db.Model):
    __table_args__ = (
        db.UniqueConstraint('planestudio_id', 'materia_id', 'anio_id', name='uix_materia_plan'),
    )    
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    planestudio_id = db.Column(db.Integer(), db.ForeignKey(PlanEstudio.id), nullable=False)
    materia_id = db.Column(db.Integer(), db.ForeignKey(Materia.id), nullable=False)
    anio_id = db.Column(db.Integer(), db.ForeignKey(Anio.id), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Persona(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    apellido = db.Column(db.String(64), index=True, nullable=False)
    nombre = db.Column(db.String(64), index=True, nullable=False)
    dni = db.Column(db.Integer(), index=True, unique=True, nullable=False)
    fnacto = db.Column(db.DateTime, nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class CargoDocente(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(64), index=True, nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Docente(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    legajo = db.Column(db.Integer(), nullable=False, default=0)
    persona_id = db.Column(db.Integer(), db.ForeignKey(Persona.id), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class DocenteCargo(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    docente_id = db.Column(db.Integer(), db.ForeignKey(Docente.id),nullable=False)
    cargodocente_id = db.Column(db.Integer(), db.ForeignKey(CargoDocente.id),nullable=False)
    finicio = db.Column(db.DateTime, nullable=False)
    ffin = db.Column(db.DateTime)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class MateriaDocente(db.Model):
    __table_args__ = (
        db.UniqueConstraint('docente_id', 'materiaplan_id', name='uix_materia_docente'),
    )
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    docente_id = db.Column(db.Integer(), db.ForeignKey(Docente.id), nullable=False)
    materiaplan_id = db.Column(db.Integer(), db.ForeignKey(MateriaPlan.id), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Comision(db.Model):
    __table_args__ = (
        db.UniqueConstraint('ciclolectivo_id', 'cuatrimestre_id', 'turno_id', 'materiadocente_id' ,name='uix_comision'),
    )
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    ciclolectivo_id = db.Column(db.Integer(), db.ForeignKey(CicloLectivo.id), nullable=False)
    cuatrimestre_id = db.Column(db.Integer(), db.ForeignKey(Cuatrimestre.id), nullable=False)
    turno_id = db.Column(db.Integer(), db.ForeignKey(Turno.id), nullable=False)
    materiadocente_id = db.Column(db.Integer(), db.ForeignKey(MateriaDocente.id),nullable=False)
    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Alumno(db.Model):
    __table_args__ = (
        db.UniqueConstraint('legajo', 'persona_id', name='uix_alumno'),
    )
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    legajo = db.Column(db.Integer(), nullable=False, default=0)
    persona_id = db.Column(db.Integer(), db.ForeignKey(Persona.id), nullable=False)
    fingreso = db.Column(db.DateTime, nullable=False)
    fegreso = db.Column(db.DateTime)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class AlumnoComision(db.Model):
    __table_args__ = (
        db.UniqueConstraint('comision_id', 'alumno_id', name='uix_alumno_comision'),
    )
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    comision_id = db.Column(db.Integer(), db.ForeignKey(Comision.id), nullable=False)
    alumno_id = db.Column(db.Integer(), db.ForeignKey(Alumno.id), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class TipoContacto(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)    
    nombre = db.Column(db.String(64), nullable=False, unique=True)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class ContactoPersona(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)    
    persona_id = db.Column(db.Integer(), db.ForeignKey(Persona.id), nullable=False)
    tipocontacto_id = db.Column(db.Integer(), db.ForeignKey(TipoContacto.id), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Usuario(UserMixin, db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(64), index=True, unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    persona_id = db.Column(db.Integer(), db.ForeignKey(Persona.id), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

class Posteo(db.Model):
    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    texto = db.Column(db.String(140), nullable=False)
    fecha = db.Column(db.DateTime, index=True, default=datetime.utcnow, nullable=False)
    usuario_id = db.Column(db.Integer(), db.ForeignKey(Usuario.id), nullable=False)

    def __repr__(self) -> str:
        return self._repr(id=self.id)

def _repr(self, **fields: typing.Dict[str, typing.Any]) -> str:
    '''
    Helper for __repr__
    '''
    print('_repr', fields)
    field_strings = []
    at_least_one_attached_attribute = False
    for key, field in fields.items():
        try:
            field_strings.append(f'{key}={field!r}')
        except sa.orm.exc.DetachedInstanceError:
            field_strings.append(f'{key}=DetachedInstanceError')
        else:
            at_least_one_attached_attribute = True
    if at_least_one_attached_attribute:
        return f"<{self.__class__.__name__}({','.join(field_strings)})>"
    
    return f"<{self.__class__.__name__} {id(self)}>"

@login.user_loader
def load_user(id):
    return Usuario.query.get(int(id))


def __repr__(o) -> str:
    return f"{o.to_dict()}"
    #return 'OK OK'
def to_dict(o):
    return {field.name:getattr(o, field.name) for field in o.__table__.c}