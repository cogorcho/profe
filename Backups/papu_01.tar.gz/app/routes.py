import json
from flask import render_template, flash, redirect, url_for, jsonify
from app import app, db
from app.forms import LoginForm, RegistroForm
from flask_login import current_user, login_user
from werkzeug.security import generate_password_hash, check_password_hash
from app.models import Persona, Usuario, Materia, Turno, Cuatrimestre, PlanEstudio

@app.route('/')
@app.route('/index')
def index():
    user = {'username': 'Juan Maria'}
    posts = [
        {
            'author': {'username': 'John'},
            'body': 'Beautiful day in Portland!'
        },
        {
            'author': {'username': 'Susan'},
            'body': 'The Avengers movie was so cool!'
        }
    ]
    return render_template('index.html', user=user, title='Black Fart', posts=posts)


@app.route('/login', methods=('GET','POST'))
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        usuario = Usuario.query.filter_by(nombre=form.usuario.data).first()
        print(usuario)
        if usuario is None:
            flash('Nombre de usuario invalido')
            return redirect(url_for(ĺogin))
        login_user(usuario, remember=form.remember_me.data)
        return redirect(url_for('index'))
    
    return render_template('login.html', title='Black Fart - Ingreso', form=form)

@app.route('/registro', methods=('GET','POST'))
def registro():
    form = RegistroForm()
    if form.validate_on_submit():
        p = Persona(
            apellido=form.apellido.data,
            nombre=form.nombre.data,
            dni=form.dni.data,
            fnacto=form.fnacto.data
        )
        db.session.add(p)
        db.session.flush()
        u = Usuario(
            nombre=form.usuario.data,
            persona_id=p.id,
            password_hash=generate_password_hash(form.password.data)
        )
        db.session.add(u)
        db.session.commit()
        flash(f'Requerimiento de ingreso para {form.apellido.data}, {form.nombre.data}')
        return redirect(url_for('index'))
    return render_template('registro.html', title='Black Fart - Registro', form=form)


@app.route('/materia', methods=('GET','POST'))
@app.route('/materia/<id>', methods=('GET','POST'))
def materia(id=None):
    return jsonify(getRows(Materia,id))

@app.route('/turno', methods=('GET','POST'))
@app.route('/turno/<id>', methods=('GET','POST'))
def turno(id=None):
    return jsonify(getRows(Turno,id))

@app.route('/planestudio', methods=('GET','POST'))
@app.route('/planestudio/<id>', methods=('GET','POST'))
def planestudio(id=None):
    return jsonify(getRows(PlanEstudio,id))

@app.route('/cuatrimestre', methods=('GET','POST'))
@app.route('/cuatrimestre/<id>', methods=('GET','POST'))
def cuatrimestre(id=None):
    return jsonify(getRows(Cuatrimestre,id))


def getRows(tabla,id=None):
    if id is None:
        rows = db.session.execute(db.select(tabla)).fetchall()
    else:
        rows = db.session.execute(db.select(tabla).where(tabla.id==id))
    data = []

    for row in rows:
        #print(row)
        r = row._mapping._to_tuple_instance()
        data.append(r[0].to_dict())
    return data

